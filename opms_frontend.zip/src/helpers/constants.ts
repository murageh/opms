export const IMAGE = (image: string) => {
  // e.g. "image.png"
  return window.location.origin + `/images/${image}`;
};
